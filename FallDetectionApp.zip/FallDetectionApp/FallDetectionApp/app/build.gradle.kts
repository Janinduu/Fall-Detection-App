plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.test01"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.test01"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // Vector drawables support for older versions
        vectorDrawables.useSupportLibrary = true
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isDebuggable = true
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    buildFeatures {
        viewBinding = false  // Set to true if you want to use view binding
        dataBinding = false  // Set to true if you want to use data binding
    }

    // Packaging options to avoid conflicts
    packagingOptions {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    // Core Android dependencies (existing)
    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)

    // Additional dependencies for Fall Detection App

    // CardView for UI cards
    implementation("androidx.cardview:cardview:1.0.0")

    // RecyclerView (if needed for lists)
    implementation("androidx.recyclerview:recyclerview:1.3.2")

    // Preferences for settings screen
    implementation("androidx.preference:preference:1.2.1")

    // Work Manager for background tasks
    implementation("androidx.work:work-runtime:2.9.0")

    // Lifecycle components
    implementation("androidx.lifecycle:lifecycle-extensions:2.2.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel:2.7.0")
    implementation("androidx.lifecycle:lifecycle-livedata:2.7.0")

    // Location services for GPS functionality
    implementation("com.google.android.gms:play-services-location:21.0.1")

    // Permission handling
    implementation("androidx.core:core:1.12.0")

    // Fragment support
    implementation("androidx.fragment:fragment:1.6.2")

    // Annotation support
    implementation("androidx.annotation:annotation:1.7.1")

    // Vector drawable support
    implementation("androidx.vectordrawable:vectordrawable:1.1.0")
    implementation("androidx.vectordrawable:vectordrawable-animated:1.1.0")

    // Testing dependencies (existing)
    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)

    // Additional testing dependencies
    testImplementation("org.mockito:mockito-core:5.7.0")
    androidTestImplementation("androidx.test:runner:1.5.2")
    androidTestImplementation("androidx.test:rules:1.5.0")
    androidTestImplementation("androidx.test.espresso:espresso-intents:3.5.1")

    implementation("com.google.android.material:material:1.9.0")
}
