package com.example.test01;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
//import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.switchmaterial.SwitchMaterial;

public class SettingsActivity extends AppCompatActivity {

    private EditText etEmergencyContact;
    private SwitchMaterial switchSMSAlerts;
    private SwitchMaterial switchVibration;
    private SeekBar seekBarSensitivity;
    private TextView tvSensitivityValue;
    private Button btnSaveSettings;
    private Button btnTestSMS;

    private SharedPreferencesHelper prefsHelper;
    private SMSManager smsManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Enable back button in action bar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Settings");
        }

        initializeViews();
        initializeHelpers();
        loadSettings();
        setupListeners();
    }

    private void initializeViews() {
        etEmergencyContact = findViewById(R.id.et_emergency_contact);
        switchSMSAlerts = findViewById(R.id.switch_sms_alerts);
        switchVibration = findViewById(R.id.switch_vibration);
        seekBarSensitivity = findViewById(R.id.seekbar_sensitivity);
        tvSensitivityValue = findViewById(R.id.tv_sensitivity_value);
        btnSaveSettings = findViewById(R.id.btn_save_settings);
        btnTestSMS = findViewById(R.id.btn_test_sms);
    }

    private void initializeHelpers() {
        prefsHelper = new SharedPreferencesHelper(this);
        smsManager = new SMSManager(this);
    }

    private void loadSettings() {
        // Load emergency contact
        String contact = prefsHelper.getEmergencyContact();
        if (contact != null) {
            etEmergencyContact.setText(contact);
        }

        // Load SMS alerts setting
        switchSMSAlerts.setChecked(prefsHelper.isSMSAlertsEnabled());

        // Load vibration setting
        switchVibration.setChecked(prefsHelper.isVibrationEnabled());

        // Load sensitivity setting
        int sensitivity = prefsHelper.getFallSensitivity();
        seekBarSensitivity.setProgress(sensitivity);
        updateSensitivityDisplay(sensitivity);
    }

    private void setupListeners() {
        btnSaveSettings.setOnClickListener(v -> saveSettings());

        btnTestSMS.setOnClickListener(v -> testSMSFunctionality());

        seekBarSensitivity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                updateSensitivityDisplay(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }

    private void updateSensitivityDisplay(int sensitivity) {
        String[] levels = {"Very Low", "Low", "Medium", "High", "Very High"};
        int levelIndex = Math.min(sensitivity / 20, levels.length - 1);
        tvSensitivityValue.setText(levels[levelIndex] + " (" + sensitivity + "%)");
    }

    private void saveSettings() {
        String contact = etEmergencyContact.getText().toString().trim();

        // Validate emergency contact
        if (TextUtils.isEmpty(contact)) {
            Toast.makeText(this, "Please enter an emergency contact number", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!isValidPhoneNumber(contact)) {
            Toast.makeText(this, "Please enter a valid phone number", Toast.LENGTH_SHORT).show();
            return;
        }

        // Save all settings
        prefsHelper.setEmergencyContact(contact);
        prefsHelper.setSMSAlertsEnabled(switchSMSAlerts.isChecked());
        prefsHelper.setVibrationEnabled(switchVibration.isChecked());
        prefsHelper.setFallSensitivity(seekBarSensitivity.getProgress());

        Toast.makeText(this, "Settings saved successfully", Toast.LENGTH_SHORT).show();
    }

    private void testSMSFunctionality() {
        String contact = etEmergencyContact.getText().toString().trim();

        if (TextUtils.isEmpty(contact)) {
            Toast.makeText(this, "Please enter and save an emergency contact first", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!isValidPhoneNumber(contact)) {
            Toast.makeText(this, "Please enter a valid phone number", Toast.LENGTH_SHORT).show();
            return;
        }

        // Send test SMS
        boolean success = smsManager.sendTestMessage(contact);
        if (success) {
            Toast.makeText(this, "Test SMS sent to " + contact, Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isValidPhoneNumber(String phoneNumber) {
        // Remove all non-digit characters
        String cleanNumber = phoneNumber.replaceAll("[^\\d]", "");

        // Check if it's a valid length (typically 10-15 digits)
        return cleanNumber.length() >= 10 && cleanNumber.length() <= 15;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        // Save settings before going back
        saveSettings();
        super.onBackPressed();
    }
}
