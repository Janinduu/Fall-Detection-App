package com.example.test01;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPreferencesHelper {

    private static final String PREF_NAME = "FallDetectionPrefs";

    // Preference keys
    private static final String KEY_EMERGENCY_CONTACT = "emergency_contact";
    private static final String KEY_SMS_ALERTS_ENABLED = "sms_alerts_enabled";
    private static final String KEY_VIBRATION_ENABLED = "vibration_enabled";
    private static final String KEY_FALL_SENSITIVITY = "fall_sensitivity";
    private static final String KEY_FIRST_RUN = "first_run";
    private static final String KEY_FALL_COUNT = "fall_count";
    private static final String KEY_LAST_FALL_TIME = "last_fall_time";

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    public SharedPreferencesHelper(Context context) {
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    // Emergency Contact
    public void setEmergencyContact(String phoneNumber) {
        editor.putString(KEY_EMERGENCY_CONTACT, phoneNumber);
        editor.apply();
    }

    public String getEmergencyContact() {
        return sharedPreferences.getString(KEY_EMERGENCY_CONTACT, null);
    }

    // SMS Alerts
    public void setSMSAlertsEnabled(boolean enabled) {
        editor.putBoolean(KEY_SMS_ALERTS_ENABLED, enabled);
        editor.apply();
    }

    public boolean isSMSAlertsEnabled() {
        return sharedPreferences.getBoolean(KEY_SMS_ALERTS_ENABLED, true);
    }

    // Vibration
    public void setVibrationEnabled(boolean enabled) {
        editor.putBoolean(KEY_VIBRATION_ENABLED, enabled);
        editor.apply();
    }

    public boolean isVibrationEnabled() {
        return sharedPreferences.getBoolean(KEY_VIBRATION_ENABLED, true);
    }

    // Fall Sensitivity (0-100)
    public void setFallSensitivity(int sensitivity) {
        editor.putInt(KEY_FALL_SENSITIVITY, sensitivity);
        editor.apply();
    }

    public int getFallSensitivity() {
        return sharedPreferences.getInt(KEY_FALL_SENSITIVITY, 50); // Default medium sensitivity
    }

    // First Run
    public void setFirstRun(boolean isFirstRun) {
        editor.putBoolean(KEY_FIRST_RUN, isFirstRun);
        editor.apply();
    }

    public boolean isFirstRun() {
        return sharedPreferences.getBoolean(KEY_FIRST_RUN, true);
    }

    // Fall Statistics
    public void incrementFallCount() {
        int currentCount = getFallCount();
        editor.putInt(KEY_FALL_COUNT, currentCount + 1);
        editor.putLong(KEY_LAST_FALL_TIME, System.currentTimeMillis());
        editor.apply();
    }

    public int getFallCount() {
        return sharedPreferences.getInt(KEY_FALL_COUNT, 0);
    }

    public long getLastFallTime() {
        return sharedPreferences.getLong(KEY_LAST_FALL_TIME, 0);
    }

    // Reset all statistics
    public void resetStatistics() {
        editor.putInt(KEY_FALL_COUNT, 0);
        editor.putLong(KEY_LAST_FALL_TIME, 0);
        editor.apply();
    }

    // Clear all preferences
    public void clearAllPreferences() {
        editor.clear();
        editor.apply();
    }

    // Get all preferences for debugging
    public void logAllPreferences() {
        android.util.Log.d("SharedPrefs", "Emergency Contact: " + getEmergencyContact());
        android.util.Log.d("SharedPrefs", "SMS Alerts: " + isSMSAlertsEnabled());
        android.util.Log.d("SharedPrefs", "Vibration: " + isVibrationEnabled());
        android.util.Log.d("SharedPrefs", "Sensitivity: " + getFallSensitivity());
        android.util.Log.d("SharedPrefs", "Fall Count: " + getFallCount());
    }
}
