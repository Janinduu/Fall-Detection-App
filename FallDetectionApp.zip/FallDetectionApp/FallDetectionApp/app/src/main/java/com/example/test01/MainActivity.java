package com.example.test01;
import android.os.Bundle;
import android.util.Log;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

// Add this import for SwitchMaterial
import com.google.android.material.switchmaterial.SwitchMaterial;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private static final int PERMISSION_REQUEST_CODE = 123;

    // UI Components
    private TextView tvAccelX, tvAccelY, tvAccelZ;
    private TextView tvGyroX, tvGyroY, tvGyroZ;
    private TextView tvFallStatus;
    private SwitchMaterial switchFallDetection;
    private Button btnSettings, btnTestFall;

    // Sensor Components
    private SensorManager sensorManager;
    private Sensor accelerometer, gyroscope;

    // Fall Detection
    private FallDetectionAlgorithm fallDetection;
    private boolean isMonitoring = false;

    // Services
    private Intent sensorServiceIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        initializeSensors();
        checkAvailableSensors();
        initializeFallDetection();
        requestPermissions();
        setupClickListeners();
    }

    private void initializeViews() {
        tvAccelX = findViewById(R.id.tv_accel_x);
        tvAccelY = findViewById(R.id.tv_accel_y);
        tvAccelZ = findViewById(R.id.tv_accel_z);
        tvGyroX = findViewById(R.id.tv_gyro_x);
        tvGyroY = findViewById(R.id.tv_gyro_y);
        tvGyroZ = findViewById(R.id.tv_gyro_z);
        tvFallStatus = findViewById(R.id.tv_fall_status);
        switchFallDetection = findViewById(R.id.switch_fall_detection);
        btnSettings = findViewById(R.id.btn_settings);
        btnTestFall = findViewById(R.id.btn_test_fall);
    }


    private void initializeSensors() {
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);

        if (accelerometer == null) {
            Toast.makeText(this, "Accelerometer not available", Toast.LENGTH_LONG).show();
        }
        if (gyroscope == null) {
            Toast.makeText(this, "Gyroscope not available", Toast.LENGTH_LONG).show();
        }
    }

    private void initializeFallDetection() {
        fallDetection = new FallDetectionAlgorithm(this);
        sensorServiceIntent = new Intent(this, SensorService.class);
    }

    private void setupClickListeners() {
        switchFallDetection.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                startFallDetection();
            } else {
                stopFallDetection();
            }
        });

        btnSettings.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intent);
        });

        btnTestFall.setOnClickListener(v -> {
            fallDetection.simulateFall();
            Toast.makeText(this, "Fall simulation triggered", Toast.LENGTH_SHORT).show();
        });
    }

    private void requestPermissions() {
        String[] permissions = {
                Manifest.permission.SEND_SMS,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.CALL_PHONE
        };

        boolean needsPermission = false;
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission)
                    != PackageManager.PERMISSION_GRANTED) {
                needsPermission = true;
                break;
            }
        }

        if (needsPermission) {
            ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE);
        }
    }

    private void startFallDetection() {
        if (accelerometer != null && gyroscope != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_FASTEST);
            sensorManager.registerListener(this, gyroscope, SensorManager.SENSOR_DELAY_FASTEST);

            startService(sensorServiceIntent);
            isMonitoring = true;
            tvFallStatus.setText("Fall Detection: ACTIVE");
            tvFallStatus.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
        }
    }

    private void stopFallDetection() {
        sensorManager.unregisterListener(this);
        stopService(sensorServiceIntent);
        isMonitoring = false;
        tvFallStatus.setText("Fall Detection: INACTIVE");
        tvFallStatus.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            updateAccelerometerDisplay(event.values);
            fallDetection.processAccelerometerData(event.values);
        } else if (event.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
            updateGyroscopeDisplay(event.values);
            fallDetection.processGyroscopeData(event.values);
        }
    }

    private void updateAccelerometerDisplay(float[] values) {
        tvAccelX.setText(String.format("X: %.2f", values[0]));
        tvAccelY.setText(String.format("Y: %.2f", values[1]));
        tvAccelZ.setText(String.format("Z: %.2f", values[2]));
    }

    private void updateGyroscopeDisplay(float[] values) {
        tvGyroX.setText(String.format("X: %.2f", values[0]));
        tvGyroY.setText(String.format("Y: %.2f", values[1]));
        tvGyroZ.setText(String.format("Z: %.2f", values[2]));
    }

    private void checkAvailableSensors() {
        List<Sensor> deviceSensors = sensorManager.getSensorList(Sensor.TYPE_ALL);

        Log.d("SensorCheck", "Available sensors on this device:");
        for (Sensor sensor : deviceSensors) {
            Log.d("SensorCheck", "- " + sensor.getName() + " (Type: " + sensor.getType() + ")");
        }

        // Check specific sensors
        if (accelerometer != null) {
            Log.d("SensorCheck", "Accelerometer: AVAILABLE");
        } else {
            Log.d("SensorCheck", "Accelerometer: NOT AVAILABLE");
        }

        if (gyroscope != null) {
            Log.d("SensorCheck", "Gyroscope: AVAILABLE");
        } else {
            Log.d("SensorCheck", "Gyroscope: NOT AVAILABLE");
        }
    }


    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Handle sensor accuracy changes if needed
    }
//
//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        getMenuInflater().inflate(R.menu.main_menu, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
//        if (item.getItemId() == R.id.action_settings) {
//            Intent intent = new Intent(this, SettingsActivity.class);
//            startActivity(intent);
//            return true;
//        }
//        return super.onOptionsItemSelected(item);
//    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allPermissionsGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allPermissionsGranted = false;
                    break;
                }
            }

            if (!allPermissionsGranted) {
                Toast.makeText(this, "Some permissions were denied. App may not work properly.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isMonitoring && accelerometer != null && gyroscope != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_FASTEST);
            sensorManager.registerListener(this, gyroscope, SensorManager.SENSOR_DELAY_FASTEST);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isMonitoring) {
            stopService(sensorServiceIntent);
        }
    }
}