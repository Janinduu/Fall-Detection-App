package com.example.test01;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

public class FallDetectionAlgorithm {

    private static final String TAG = "FallDetection";

    // Thresholds for fall detection
    private static final float FALL_THRESHOLD = 30.0f; // m/s²
    private static final float IMPACT_THRESHOLD = 15.0f; // m/s²
    private static final float INACTIVITY_THRESHOLD = 2.0f; // m/s²
    private static final long IMPACT_WINDOW = 750; // milliseconds
    private static final long INACTIVITY_WINDOW = 2000; // milliseconds

    private Context context;
    private SMSManager smsManager;

    // Sensor data storage
    private float[] lastAccelData = new float[3];
    private float[] lastGyroData = new float[3];

    // Fall detection state
    private boolean fallDetected = false;
    private boolean impactDetected = false;
    private long impactTime = 0;
    private Handler handler;

    // Data filtering
    private static final int BUFFER_SIZE = 10;
    private float[][] accelBuffer = new float[BUFFER_SIZE][3];
    private int bufferIndex = 0;

    public FallDetectionAlgorithm(Context context) {
        this.context = context;
        this.smsManager = new SMSManager(context);
        this.handler = new Handler(Looper.getMainLooper());
    }

    public void processAccelerometerData(float[] values) {
        // Store current data
        System.arraycopy(values, 0, lastAccelData, 0, 3);

        // Add to buffer for smoothing
        System.arraycopy(values, 0, accelBuffer[bufferIndex], 0, 3);
        bufferIndex = (bufferIndex + 1) % BUFFER_SIZE;

        // Calculate magnitude
        float magnitude = calculateMagnitude(values);

        // Log for debugging
        Log.d(TAG, "Accel magnitude: " + magnitude);

        // Check for fall pattern
        checkForFall(magnitude);
    }

    public void processGyroscopeData(float[] values) {
        System.arraycopy(values, 0, lastGyroData, 0, 3);

        // Calculate angular velocity magnitude
        float angularMagnitude = calculateMagnitude(values);

        // Use gyroscope data to confirm fall (high rotation during fall)
        if (impactDetected && angularMagnitude > 5.0f) {
            Log.d(TAG, "High angular velocity detected: " + angularMagnitude);
        }
    }

    private void checkForFall(float magnitude) {
        long currentTime = System.currentTimeMillis();

        // Phase 1: Check for free fall (low acceleration)
        if (magnitude < 2.0f && !impactDetected) {
            Log.d(TAG, "Possible free fall detected");
        }

        // Phase 2: Check for impact (high acceleration)
        if (magnitude > FALL_THRESHOLD && !impactDetected) {
            impactDetected = true;
            impactTime = currentTime;
            Log.d(TAG, "Impact detected! Magnitude: " + magnitude);

            // Start monitoring for inactivity
            handler.postDelayed(this::checkForInactivity, IMPACT_WINDOW);
        }

        // Reset impact detection after time window
        if (impactDetected && (currentTime - impactTime) > IMPACT_WINDOW * 2) {
            impactDetected = false;
            Log.d(TAG, "Impact detection reset");
        }
    }

    private void checkForInactivity() {
        if (!impactDetected) return;

        // Calculate average magnitude over recent readings
        float avgMagnitude = calculateAverageMagnitude();

        Log.d(TAG, "Checking inactivity. Average magnitude: " + avgMagnitude);

        // If person is inactive after impact, likely a fall
        if (avgMagnitude < INACTIVITY_THRESHOLD) {
            confirmFall();
        } else {
            // Reset if person is moving normally
            impactDetected = false;
            Log.d(TAG, "False alarm - person is moving normally");
        }
    }

    private void confirmFall() {
        if (fallDetected) return; // Prevent multiple alerts

        fallDetected = true;
        Log.w(TAG, "FALL CONFIRMED! Sending alert...");

        // Send SMS alert
        smsManager.sendFallAlert();

        // Reset after delay to allow for new fall detection
        handler.postDelayed(() -> {
            fallDetected = false;
            impactDetected = false;
            Log.d(TAG, "Fall detection reset");
        }, 30000); // 30 seconds cooldown
    }

    private float calculateMagnitude(float[] values) {
        return (float) Math.sqrt(values[0] * values[0] +
                values[1] * values[1] +
                values[2] * values[2]);
    }

    private float calculateAverageMagnitude() {
        float sum = 0;
        int count = 0;

        for (float[] reading : accelBuffer) {
            if (reading[0] != 0 || reading[1] != 0 || reading[2] != 0) {
                sum += calculateMagnitude(reading);
                count++;
            }
        }

        return count > 0 ? sum / count : 0;
    }

    public void simulateFall() {
        Log.d(TAG, "Simulating fall for testing");
        confirmFall();
    }

    public boolean isFallDetected() {
        return fallDetected;
    }

    public void reset() {
        fallDetected = false;
        impactDetected = false;
        impactTime = 0;
        bufferIndex = 0;
        accelBuffer = new float[BUFFER_SIZE][3];
    }
}
