package com.example.test01;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class SMSManager {

    private static final String TAG = "SMSManager";
    private Context context;
    private SharedPreferencesHelper prefsHelper;
    private LocationManager locationManager;

    public SMSManager(Context context) {
        this.context = context;
        this.prefsHelper = new SharedPreferencesHelper(context);
        this.locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
    }

    public void sendFallAlert() {
        String emergencyContact = prefsHelper.getEmergencyContact();

        if (emergencyContact == null || emergencyContact.isEmpty()) {
            Log.e(TAG, "No emergency contact set");
            showToast("No emergency contact configured!");
            return;
        }

        String message = createFallAlertMessage();
        sendSMS(emergencyContact, message);
    }

    private String createFallAlertMessage() {
        StringBuilder message = new StringBuilder();
        message.append("🚨 FALL ALERT 🚨\n");
        message.append("A fall has been detected!\n\n");

        // Add timestamp
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        message.append("Time: ").append(sdf.format(new Date())).append("\n");

        // Add location if available
        String location = getCurrentLocation();
        if (location != null) {
            message.append("Location: ").append(location).append("\n");
        }

        message.append("\nThis is an automated message from Fall Detection App.");
        message.append("\nIf this is a false alarm, please ignore.");

        return message.toString();
    }

    private String getCurrentLocation() {
        try {
            Location location = null;

            // Try GPS first
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            }

            // Fallback to network location
            if (location == null && locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            }

            if (location != null) {
                double latitude = location.getLatitude();
                double longitude = location.getLongitude();
                return String.format(Locale.getDefault(), "%.6f, %.6f", latitude, longitude);
            }
        } catch (SecurityException e) {
            Log.e(TAG, "Location permission not granted", e);
        }

        return null;
    }

    private void sendSMS(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();

            // Split message if it's too long
            if (message.length() > 160) {
                java.util.ArrayList<String> parts = smsManager.divideMessage(message);
                smsManager.sendMultipartTextMessage(phoneNumber, null, parts, null, null);
            } else {
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            }

            Log.i(TAG, "Fall alert SMS sent to: " + phoneNumber);
            showToast("Fall alert sent!");

        } catch (Exception e) {
            Log.e(TAG, "Failed to send SMS", e);
            showToast("Failed to send fall alert SMS");
        }
    }

    public boolean sendTestMessage(String phoneNumber) {
        try {
            String testMessage = "This is a test message from Fall Detection App. Your emergency contact is configured correctly.";
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, testMessage, null, null);

            Log.i(TAG, "Test SMS sent to: " + phoneNumber);
            showToast("Test message sent!");
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Failed to send test SMS", e);
            showToast("Failed to send test message");
            return false;
        }
    }

    private void showToast(String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }
}
